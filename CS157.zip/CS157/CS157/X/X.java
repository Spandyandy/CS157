import objectdraw.*;
import java.awt.*;
public Class X 
   {
      Public X()