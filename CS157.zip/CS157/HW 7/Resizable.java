public interface Resizable {
public void resize (double size);
public boolean contains (Location point);
}