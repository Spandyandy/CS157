public class test
{
    public static void main(String[] args){
    String s = "Elephant";
    System.out.println(FakeCase.toLower(s));
}
}    