SetOptions[$FrontEndSession,
StyleSheetPath -> {ParentList, FrontEnd`FileName[
   {"/Applications/Mathematica.app/SystemFiles/Components/MUnit/FrontEnd", 
    "StyleSheets"}, "PacletManager" -> True]}
,
PrivatePaths -> {"SystemResources" -> {ParentList, 
    FrontEnd`FileName[
     {"/Applications/Mathematica.app/SystemFiles/Components/MUnit/FrontEnd", 
      "SystemResources"}, "PacletManager" -> True]}, 
  "Bitmaps" -> {ParentList}, "AutocompletionData" -> {ParentList}, 
  "TextResources" -> {FrontEnd`FileName[{$UserBaseDirectory, "Paclets", 
      "Repository", "PredictiveInterface-Mac-2.4.316", "FrontEnd", 
      "TextResources"}, "PacletManager" -> True, "Prepend" -> True], 
    FrontEnd`FileName[{$UserBaseDirectory, "Paclets", "Repository", 
      "WolframAlphaClient-2.2.2015060408", "FrontEnd", "TextResources"}, 
     "PacletManager" -> True, "Prepend" -> True], ParentList, 
    FrontEnd`FileName[
     {"/Applications/Mathematica.app/SystemFiles/Components/MUnit/FrontEnd", 
      "TextResources"}, "PacletManager" -> True]}}
]