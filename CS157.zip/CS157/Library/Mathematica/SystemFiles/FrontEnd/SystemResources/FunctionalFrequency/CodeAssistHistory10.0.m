{
5420,
{"For[If]", 4},
{"For", 2},
{"For[Print]", 3},
{"Print", 2},
{"For[RandomInteger]", 2},
{"For[For]", 2}
}
