Paclet[Name->"PredictiveInterface",
	Version->"2.4.316",
	MathematicaVersion->"10+",
	SystemID->{"MacOSX-x86-64"},
	PlatformQualifier->"Mac",
	Internal->True,
	Root->".",
	Extensions->{
		{"Kernel", Root->"Kernel", Context->"PredictiveInterface`"},
		{"FrontEnd", Prepend->True}
	}
]