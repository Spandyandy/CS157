(* Paclet Info File *)

(* created 2014/07/03*)

Paclet[
    Name -> "EntityFramework",
    Version -> "1.2.0",
    MathematicaVersion -> "10.0.*",
    Extensions -> 
        {
            {"Kernel", Root -> "Kernel", Context -> 
                {"EntityFrameworkLoader`", "EntityFramework`"}
            }
        }
]


