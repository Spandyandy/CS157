
Paclet[
    Name -> "WolframAlphaClient",
    Version -> "2.2.2015060408",
    MathematicaVersion -> "10+",
    Root -> ".",
    Internal -> True,
    Extensions -> 
        {
            {"Kernel", Root -> "Kernel", Context -> "WolframAlphaClient`"}, 
            {"FrontEnd", Prepend -> True}
        }
]


