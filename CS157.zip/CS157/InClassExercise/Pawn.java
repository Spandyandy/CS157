public class Pawn extends ChessPiece {

    public static final int pointValue = 1;

    public Pawn(String s, Image im, Square sq, DrawingCanvas dc) {
        
    }

    public void move(String position) {...}

    public void draw(String position) {...}
}
