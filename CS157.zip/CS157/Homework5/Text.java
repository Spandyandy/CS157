public class Text{
    private static Quadratic quad;
    public static void main(String[] args){
        quad = new Quadratic(4,4,1);
        quad.quadraticFormula();
    }
}
        